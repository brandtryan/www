test("making sure qunit works", function() {
	ok(1 == "1", "Passed!");
});